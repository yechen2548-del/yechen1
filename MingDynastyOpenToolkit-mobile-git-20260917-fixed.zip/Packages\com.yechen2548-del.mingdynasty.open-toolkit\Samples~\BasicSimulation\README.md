# Basic Simulation sample

This sample demonstrates a minimal Unity-side composition:

1. construct an instance-scoped clock, calendar, event bus, and time service;
2. subscribe to `GameTimeAdvancedEvent`;
3. advance the service from `MonoBehaviour.Update`.

The sample intentionally creates all dependencies in code and uses no scenes, prefabs, art, or project-specific content.

Copy `BasicSimulationExample.cs` into a host project's scripts or use it as a reference after importing the sample through Unity Package Manager.
