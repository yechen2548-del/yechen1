# MingDynasty Open Toolkit

Reusable, engine-light Unity tools and simulation components extracted and generalized from the development of [MingDynastyGame](https://github.com/yechen2548-del/yechen1), a historical city-building and society simulation project.

This repository is intentionally **not** the MingDynastyGame project. It contains only small, reusable runtime building blocks that can be used by other Unity projects.

## What this project is

The toolkit addresses recurring infrastructure problems in data-driven simulations:

- instance-scoped events, commands, services, registries, settings, logging, and debug commands;
- stable identifiers, deterministic random numbers, scheduling, performance samples, and versioned save envelopes;
- calendar/time progression with configurable seasons;
- simulation ticks with catch-up caps;
- world/chunk coordinates and distance-based chunk lifecycle management;
- simulation LOD policies, fair work rotation, and per-chunk budgets;
- capacity-limited inventories with reservations, transfers, snapshots, and atomic multi-resource transactions.

The runtime assemblies do not reference `UnityEngine`. They are plain C# assemblies packaged for Unity, which keeps the domain logic testable and usable in headless or non-visual simulation code.

## Source and scope

The code was selected from the local working MingDynastyGame Unity project:

- `Assets/Game/Core/Runtime` — included after namespace and save-envelope generalization;
- selected files from `Assets/Game/Simulation/Runtime` — coordinates, chunk lifecycle, time, ticks, LOD, and resource inventory;
- game-specific presentation, content, population, building, military, economy, world-art, editor-generator, scene, and asset files — intentionally excluded.

No models, textures, audio, fonts, third-party packages, Unity scenes, or generated build data are included.

## Current status

Early-stage toolkit prepared for public source review. The package metadata is versioned as `0.1.0`; no GitHub Release has been created.

Static package, assembly-definition, stale-reference, brace-balance, and secret-marker checks have been completed. A standalone C# compilation was not available in the source environment because no C# SDK/compiler was installed. Unity EditMode tests are included for a Unity host, but the Unity Editor was also unavailable, so both the compiler check and Unity tests still need to be run before a public release.

## Requirements

- Unity 2022.3 LTS or newer;
- the package's runtime code has no external runtime package dependency;
- the included tests use the Unity Test Framework supplied by the host project.

## Installation

### Local package installation

Copy `Packages/com.yechen2548-del.mingdynasty.open-toolkit` into a Unity project's `Packages/` directory and add it to that project's `Packages/manifest.json`:

```json
{
  "dependencies": {
    "com.yechen2548-del.mingdynasty.open-toolkit": "file:../Packages/com.yechen2548-del.mingdynasty.open-toolkit"
  }
}
```

Alternatively, use Unity Package Manager's **Add package from disk...** and select the package's `package.json`.

After the package is available, import the `Basic Simulation` sample from Package Manager if you want a small `MonoBehaviour` integration example.

## Usage examples

### Time and calendar

```csharp
using MingDynasty.OpenToolkit.Core;
using MingDynasty.OpenToolkit.Simulation;

var clock = new GameClock();
var calendar = new GenericCalendar(new CalendarDefinition());
var time = new GameTimeService(clock, calendar, null, null, secondsPerGameHour: 1.0d);

time.AdvanceGameHours(6.0d);
UnityEngine.Debug.Log(time.FormatCurrentTime());
```

### Reserved inventory transaction

```csharp
using MingDynasty.OpenToolkit.Core;
using MingDynasty.OpenToolkit.Simulation;

var warehouse = new Inventory(StableId.New("warehouse"), capacity: 1000);
warehouse.TryAdd("grain", 50);

var cost = new[] { new ResourceAmount("grain", 12) };
var transaction = new ResourceTransaction(warehouse, StableId.New("build"), cost);
var result = transaction.TryCommit();
```

### Event subscription

```csharp
using MingDynasty.OpenToolkit.Core;

var events = new GameEventBus();
using (events.Subscribe<MyEvent>(value => Handle(value)))
{
    events.Publish(new MyEvent());
}
```

See `Samples~/BasicSimulation/README.md` and the tests under `Tests/Editor/` for more complete examples.

## Repository layout

```text
Packages/
  com.yechen2548-del.mingdynasty.open-toolkit/
    Runtime/Core/          engine-light infrastructure
    Runtime/Simulation/    time, chunks, LOD, ticks, inventory
    Tests/Editor/           Unity Test Framework tests
    Samples~/BasicSimulation/
AUDIT.md                    extraction, exclusion, and risk record
CONTRIBUTING.md
SECURITY.md
CHANGELOG.md
LICENSE
```

## Roadmap

1. Run the included EditMode tests in a clean Unity 2022.3 host project.
2. Add a small sample scene only if it can remain asset-free and genuinely clarifies integration.
3. Improve API documentation and add XML documentation where the public contract is non-obvious.
4. Consider optional Unity adapters in a separate assembly; keep the core runtime free of `UnityEngine` dependencies.

## Contributing

Bug reports, focused improvements, tests, and documentation changes are welcome. Please read [CONTRIBUTING.md](CONTRIBUTING.md) before opening a pull request.

## Security

Please read [SECURITY.md](SECURITY.md) for responsible reporting. Do not commit secrets, local configuration, credentials, generated Unity folders, or private project data.

## License

The original toolkit code in this repository is released under the MIT License. See [LICENSE](LICENSE). Third-party assets are not redistributed by this repository.

### 中文说明

这是从 MingDynastyGame 中筛选出的、经过通用化处理的 Unity/C# 底层工具集合，不是明朝游戏主工程的公开副本。本仓库不包含游戏场景、美术资源、历史内容、人口/建筑/军事/经济等核心玩法实现，也没有上传 GitHub 的操作记录。
